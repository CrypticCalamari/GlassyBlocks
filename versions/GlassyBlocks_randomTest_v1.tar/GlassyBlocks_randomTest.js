var nextStateMap = new Map([
	["on", "off"],
	["off", "on"]
]);

class Cell {
	constructor(x, y, w, h, state, id) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
		this.state = state;
		this.town = [];
		this.cell = document.createElement("div");
		this.cell.className = state;
		this.cell.id = id;
		this.rLeft = Math.floor(Math.random() * (window.innerWidth - w));
		this.rTop = Math.floor(Math.random() * (window.innerHeight - h));
		this.curLeft = this.rLeft;
		this.curTop = this.rTop;
		this.cell.style.left = this.rLeft + "px";
		this.cell.style.top = this.rTop + "px";
		this.cell.style.width = w + "px";
		this.cell.style.height = h + "px";
		this.cell.addEventListener("click", (e) => {
			this.trigger(null, true);
		});
		document.body.appendChild(this.cell);
	}
	trigger(cCell, direct) {
		if (direct) {
			for (let x of this.town) {
				x.trigger(this, false);
			}
		}

		// temporary global reference
		this.state = nextStateMap.get(this.state);
		this.cell.className = this.state;
		if (!direct) {
			if (this.state == "off") {
				this.cell.style.left = this.rLeft + "px";
				this.cell.style.top = this.rTop + "px";
			} else {
				if (this.x < cCell.x) {
					this.curLeft = cCell.curLeft - this.w - 1;
					this.curTop = cCell.curTop;
				} else if (this.x > cCell.x) {
					this.curLeft = cCell.curLeft + this.w + 1;
					this.curTop = cCell.curTop;
				} else if (this.y < cCell.y) {
					this.curLeft = cCell.curLeft;
					this.curTop = cCell.curTop - this.h - 1;
				} else {
					this.curLeft = cCell.curLeft;
					this.curTop = cCell.curTop + this.h + 1;
				}
				this.cell.style.left = this.curLeft + "px";
				this.cell.style.top = this.curTop + "px";
			}
		}
	}
}

class Board {
	constructor(rows, cols, w, h) {
		this.rows = rows;
		this.cols = cols;
		this.board = [];
		
		for (let i = 0; i < rows; i++) {
			for (let j = 0; j < cols; j++) {
				let cell = new Cell(j, i, w, h, "off", "cell_" + (j + i * cols));
				this.board.push(cell);
			}
		}

		for (let i = 0; i < rows; i++) {
			for (let j = 0; j < cols; j++) {
				if (i - 1 >= 0)
					this.board[j + i * this.cols].town.push( this.board[j + (i-1) * cols] );
				if (i + 1 < rows)
					this.board[j + i * this.cols].town.push( this.board[j + (i+1) * cols] );
				if (j - 1 >= 0)
					this.board[j + i * this.cols].town.push( this.board[j-1 + i * cols] );
				if (j + 1 < cols)
					this.board[j + i * this.cols].town.push( this.board[j+1 + i * cols] );
			}
		}
	}
}

var board = new Board(4, 4, 100, 100);










