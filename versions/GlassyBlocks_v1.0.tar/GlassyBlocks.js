
var nextStateMap = new Map([
	["on", "off"],
	["off", "on"]
]);

class Cell {
	constructor(x, y, state) {
		this.x = x;
		this.y = y;
		this.state = state;
		this.town = [];
		this.element = document.createElement("div");
		this.element.className = state;
		this.element.addEventListener("click", (e) => {
			this.trigger(nextStateMap, true);
		});
	}
	trigger(nextStateMap, direct) {
		console.log("triggered");
		if (direct)
			for (let buddy of this.town)
				buddy.trigger(nextStateMap, false)

		this.state = nextStateMap.get(this.state);
		this.element.className = this.state;
	}
}

class Board {
	constructor(rows, cols) {
		this.rows = rows;
		this.cols = cols;
		this.board = [];
		this.table = document.createElement("table");

		for (let i = 0; i < rows; i++)
			this.board.push([]);

		for (let i = 0; i < rows; i++) {
			for (let j = 0; j < cols; j++) {
				this.board[j][i] = new Cell(j, i, "off")
			}
		}

		// Remove when you figure out CSS
		for (let i = 0; i < rows; i++) {
			let row = document.createElement("tr");
			for (let j = 0; j < cols; j++) {
				let cell = document.createElement("td");
				cell.appendChild(this.board[j][i].element);
				row.appendChild(cell);
			}
			this.table.appendChild(row);
		}

		for (let i = 0; i < rows; i++) {
			for (let j = 0; j < cols; j++) {
				if (i - 1 >= 0)
					this.board[j][i].town.push( this.board[j][i-1] );
				if (i + 1 < rows)
					this.board[j][i].town.push( this.board[j][i+1] );
				if (j - 1 >= 0)
					this.board[j][i].town.push( this.board[j-1][i] );
				if (j + 1 < cols)
					this.board[j][i].town.push( this.board[j+1][i] );
			}
		}
	}
}

var board = new Board(10, 10);

document.body.appendChild(board.table);





